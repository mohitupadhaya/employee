<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2020 &copy; Mohit Admin. Brought to you by <a href="#">Mohit Developer</a> </div>
</div>

<!--end-Footer-part-->