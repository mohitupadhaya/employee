

<?php $__env->startSection('content'); ?>
<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Matrix Admin</a></h1>
</div>
<!--close-Header-part--> 

<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Employee</a> </div>
    <h1>Employee</h1>
      
  </div>
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Employee Details</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table" id="myTable">
              <thead>
                <tr>
                  <th>Employee Id</th>
                  <th>Employee Name</th>
                  <th>Employee Age</th>
                  <th>Employee Mobile</th>
                  <th>Employee Email</th>
                  <th>Employee Salary</th>
                  <th>Employee Department</th>
                  <th>Employee Designation</th>
                  <?php if(!Auth::user()->admin==0): ?>
                  <th>Status</th>
                  
                   <?php endif; ?>
                </tr>
              </thead>
              <tbody>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $emp->employeeofiicial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($emp->status=="1"): ?>
                <tr class="gradeU">
                  <td><?php echo e($emp->emp_id); ?></td>
                  <td><?php echo e($employee->emp_name); ?></td>
                  <td><?php echo e($employee->emp_age); ?></td>
                  <td><?php echo e($employee->emp_mobile); ?></td>
                  <td><?php echo e($employee->emp_email); ?></td>
                  <td><?php echo e($emp->emp_salary); ?></td>
                  <td><?php echo e($emp->emp_department); ?></td>
                  <td>
                   <?php echo e($emp->emp_designation); ?>

                  </td>
                  <?php else: ?> 
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <?php endif; ?>

                  <?php if(!Auth::user()->admin==0): ?>
                  <td>
                      <?php if($emp->status==1): ?>
                 <a href="<?php echo e(url('employee/changestatus/'.$emp->id)); ?>" class="btn btn-success">Enable</a>
                 <?php else: ?>
                <a href="<?php echo e(url('employee/changestatus/'.$emp->id)); ?>" class="btn btn-warning">Disable</a>
                 <?php endif; ?>
                 <?php endif; ?>
                  </td>
            
                </tr>   
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/employee/employee.blade.php ENDPATH**/ ?>